import json
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import random
import copy

# Fun names
ADJECTIVES = [
    "Heavenly", "Divine", "Magical", "Dreamy", "Sublime", "Blissful", "Enchanted",
    "Decadent", "Luscious", "Delightful", "Wonderful", "Marvelous", "Spectacular",
    "Ultimate", "Perfect", "Supreme", "Glorious", "Radiant", "Golden", "Sparkling",
    "Velvet", "Silky", "Fluffy", "Crispy", "Crunchy", "Gooey", "Fudgy", "Caramelized",
    "Secret", "Hidden", "Mystery", "Surprise", "Twisted", "Wild", "Crazy", "Whimsical",
    "Rustic", "Classic", "Modern", "Vintage", "Retro", "Artisan", "Gourmet", "Fancy",
    "Midnight", "Sunset", "Summer", "Winter", "Spring", "Autumn", "Harvest", "Garden"
]

DESCRIPTORS = [
    "Delight", "Dream", "Fantasy", "Treasure", "Bliss", "Paradise", "Heaven",
    "Wonder", "Magic", "Charm", "Joy", "Love", "Kiss", "Hug", "Whisper",
    "Symphony", "Medley", "Fusion", "Harmony", "Melody", "Rhapsody", "Serenade",
    "Sensation", "Temptation", "Indulgence", "Craving", "Obsession", "Passion",
    "Creation", "Masterpiece", "Invention", "Discovery", "Adventure", "Journey",
    "Cloud", "Swirl", "Burst", "Explosion", "Wave", "Storm", "Thunder"
]

STYLE_PREFIXES = [
    "Grandma's", "Chef's", "Baker's", "Mom's", "Aunt's", "Uncle's",
    "Triple", "Double", "Ultimate", "Super", "Mega", "Extra",
    "Homestyle", "Country", "City", "Downtown", "Uptown",
    "Midnight", "Morning", "Afternoon", "Evening"
]

# Ingredient-specific adjectives
INGREDIENT_DESCRIPTORS = {
    'chocolate': ['Chocolatey', 'Cocoa', 'Mocha', 'Dark', 'Rich'],
    'vanilla': ['Vanilla', 'Classic', 'Pure', 'French'],
    'lemon': ['Lemony', 'Citrus', 'Zesty', 'Tangy'],
    'strawberry': ['Berry', 'Strawberry', 'Fresh', 'Fruity'],
    'apple': ['Apple', 'Orchard', 'Harvest', 'Autumn'],
    'cherry': ['Cherry', 'Ruby', 'Sweet'],
    'peanut butter': ['Nutty', 'Peanut', 'Creamy'],
    'caramel': ['Caramel', 'Butterscotch', 'Toffee'],
    'coconut': ['Tropical', 'Coconut', 'Island'],
    'pumpkin': ['Pumpkin', 'Spiced', 'Harvest'],
    'banana': ['Banana', 'Tropical', 'Smooth'],
    'blueberry': ['Blueberry', 'Berry', 'Wild'],
    'pecan': ['Pecan', 'Nutty', 'Southern'],
    'walnut': ['Walnut', 'Nutty', 'Crunchy'],
    'almond': ['Almond', 'Nutty', 'Toasted'],
    'cinnamon': ['Cinnamon', 'Spiced', 'Warm'],
    'ginger': ['Ginger', 'Spicy', 'Zingy'],
    'mint': ['Mint', 'Cool', 'Fresh'],
    'coffee': ['Coffee', 'Espresso', 'Mocha']
}

def deduplicate_ingredients(recipe):
    """
    Sometimes the same ingredient appears twice in a recipe which doesn't make sense
    This function removes duplicates
    """
    unique_ingredients = []
    seen_ingredient_names = set()
    
    for ing in recipe['ingredients']:
        if ing['ingredient'] not in seen_ingredient_names:
            unique_ingredients.append(ing)
            seen_ingredient_names.add(ing['ingredient'])
    
    recipe['ingredients'] = unique_ingredients
    current_ingredient_names = set()
    for ing in recipe['ingredients']:
        current_ingredient_names.add(ing['ingredient'])
    
    new_step_map = {}
    for ing_name in recipe['step_map']:
        if ing_name in current_ingredient_names:
            new_step_map[ing_name] = recipe['step_map'][ing_name]
    recipe['step_map'] = new_step_map
    
    return recipe

def generate_recipe_name(recipe, category, used_names):
    """
    Generate a fun, creative name for a recipe based on ingredients and category
    Ensures uniqueness by checking against used_names set
    """
    ingredients = []
    for ing in recipe['ingredients']:
        ingredients.append(ing['ingredient'].lower())
    
    # Find key ingredients (special ones that should be featured)
    key_ingredients = []
    for ing in ingredients:
        for key in INGREDIENT_DESCRIPTORS.keys():
            if key in ing:
                key_ingredients.append(key)
    
    # Remove duplicates from key_ingredients
    key_ingredients = list(set(key_ingredients))
    
    # Capitalize category name properly
    category_name = category.capitalize()
    if category == 'ice cream':
        category_name = 'Ice Cream'
    
    # Try different name patterns until we get a unique one
    max_attempts = 50
    for attempt in range(max_attempts):
        pattern = random.randint(1, 8)
        
        if pattern == 1 and key_ingredients:
            # Pattern: "[Key Ingredient] [Adjective] [Category]"
            # e.g., "Chocolate Divine Cake"
            key_ing = random.choice(key_ingredients)
            descriptor = random.choice(INGREDIENT_DESCRIPTORS[key_ing])
            adjective = random.choice(ADJECTIVES)
            name = f"{descriptor} {adjective} {category_name}"
        
        elif pattern == 2:
            # Pattern: "[Adjective] [Descriptor] [Category]"
            # e.g., "Heavenly Bliss Pie"
            adjective = random.choice(ADJECTIVES)
            descriptor = random.choice(DESCRIPTORS)
            name = f"{adjective} {descriptor} {category_name}"
        
        elif pattern == 3 and key_ingredients:
            # Pattern: "[Key Ingredient] [Descriptor]"
            # e.g., "Chocolate Symphony"
            key_ing = random.choice(key_ingredients)
            descriptor_from_ing = random.choice(INGREDIENT_DESCRIPTORS[key_ing])
            descriptor = random.choice(DESCRIPTORS)
            name = f"{descriptor_from_ing} {descriptor}"
        
        elif pattern == 4 and len(key_ingredients) >= 2:
            # Pattern: "[Ingredient1] [Ingredient2] [Category]"
            # e.g., "Chocolate Cherry Cake"
            ing1 = random.choice(key_ingredients)
            other_ings = []
            for i in key_ingredients:
                if i != ing1:
                    other_ings.append(i)
            if other_ings:  # Safety check
                ing2 = random.choice(other_ings)
                desc1 = random.choice(INGREDIENT_DESCRIPTORS[ing1])
                desc2 = random.choice(INGREDIENT_DESCRIPTORS[ing2])
                name = f"{desc1} {desc2} {category_name}"
            else:
                # Fallback to single ingredient pattern
                desc1 = random.choice(INGREDIENT_DESCRIPTORS[ing1])
                adjective = random.choice(ADJECTIVES)
                name = f"{desc1} {adjective} {category_name}"
        
        elif pattern == 5:
            # Pattern: "[Style Prefix] [Adjective] [Category]"
            # e.g., "Grandma's Golden Cookies"
            prefix = random.choice(STYLE_PREFIXES)
            adjective = random.choice(ADJECTIVES)
            name = f"{prefix} {adjective} {category_name}"
        
        elif pattern == 6 and key_ingredients:
            # Pattern: "[Adjective] [Ingredient] [Descriptor]"
            # e.g., "Decadent Chocolate Dream"
            key_ing = random.choice(key_ingredients)
            descriptor_from_ing = random.choice(INGREDIENT_DESCRIPTORS[key_ing])
            adjective = random.choice(ADJECTIVES)
            descriptor = random.choice(DESCRIPTORS)
            name = f"{adjective} {descriptor_from_ing} {descriptor}"
        
        elif pattern == 7 and key_ingredients:
            # Pattern: "The [Adjective] [Ingredient] [Category]"
            # e.g., "The Ultimate Chocolate Pie"
            key_ing = random.choice(key_ingredients)
            descriptor_from_ing = random.choice(INGREDIENT_DESCRIPTORS[key_ing])
            adjective = random.choice(ADJECTIVES)
            name = f"The {adjective} {descriptor_from_ing} {category_name}"
        
        else:
            # Pattern: "[Style Prefix] [Category] [Descriptor]"
            # e.g., "Chef's Pie Paradise"
            prefix = random.choice(STYLE_PREFIXES)
            descriptor = random.choice(DESCRIPTORS)
            name = f"{prefix} {category_name} {descriptor}"
        
        # Check if name is unique
        if name not in used_names:
            used_names.add(name)
            return name
    
    # Fallback: add a number to make it unique
    base_name = f"{random.choice(ADJECTIVES)} {category_name} {random.choice(DESCRIPTORS)}"
    counter = 1
    name = base_name
    while name in used_names:
        name = f"{base_name} #{counter}"
        counter += 1
    
    used_names.add(name)
    return name

def load_data(file_path):
    """
    Load the recipe data from JSON file
    Returns a pandas dataframe because it's easier to work with
    """
    # open and read the JSON file
    f = open(file_path, 'r')
    data = json.load(f)
    f.close()
    
    # convert to dataframe
    df = pd.DataFrame(data)
    return df

def preprocess_data(recipe_data):
    """
    This function processes all the recipe data to extract useful information
    It creates lists of all ingredients, units, actions, etc.
    Also creates the TF-IDF matrix for comparing recipes
    """
    all_ingredients = set()
    all_units = set()
    ingredient_to_units_map = {}
    ingredient_info = {}
    roles_to_ingredients = {}
    classes_to_ingredients = {}
    ingredient_amounts = {}
    
    for ingredients in recipe_data['ingredients']:
        for ing in ingredients:
            ing_name = ing['ingredient']
            all_ingredients.add(ing_name)
            all_units.add(ing['unit'])
            if ing_name not in ingredient_to_units_map:
                ingredient_to_units_map[ing_name] = set()
            if ing['unit']:
                ingredient_to_units_map[ing_name].add(ing['unit'])
            if ing_name not in ingredient_info:
                ingredient_info[ing_name] = {'role': ing['role'], 'class': ing['class']}
            if ing['role'] not in roles_to_ingredients:
                roles_to_ingredients[ing['role']] = set()
            roles_to_ingredients[ing['role']].add(ing_name)
            if ing['class'] not in classes_to_ingredients:
                classes_to_ingredients[ing['class']] = set()
            classes_to_ingredients[ing['class']].add(ing_name)
            key = (ing_name, ing['unit'])
            if key not in ingredient_amounts:
                ingredient_amounts[key] = []
            if ing['amount'] is not None:
                ingredient_amounts[key].append(ing['amount'])
    
    all_actions = []
    
    corpus = []
    for ingredients in recipe_data['ingredients']:
        names = []
        for ing in ingredients:
            names.append(ing['ingredient'])
        ingredient_string = ' '.join(names)
        corpus.append(ingredient_string)
    
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(corpus)
    
    amount_stats = {}
    for key in ingredient_amounts:
        amounts = ingredient_amounts[key]
        if amounts:
            arr = np.array(amounts)
            amount_stats[key] = {
                'mean': np.mean(arr),
                'std': np.std(arr),
                'min': np.min(arr),
                'max': np.max(arr)
            }
    
    return (list(all_ingredients), list(all_units), list(all_actions), 
            vectorizer, tfidf_matrix, ingredient_to_units_map, 
            ingredient_info, roles_to_ingredients, classes_to_ingredients, amount_stats)

def get_sensible_amount(ingredient, unit, amount_stats):
    """
    Generate a realistic amount for an ingredient
    Uses statistics from the original dataset
    """
    key = (ingredient, unit)
    
    # if we have stats for this ingredient+unit, use them
    if key in amount_stats:
        stats = amount_stats[key]
        # generate amount from normal distribution
        amount = np.random.normal(stats['mean'], stats['std'] if stats['std'] > 0 else 0.1)
        # clip to min/max
        amount = np.clip(amount, stats['min'], stats['max'])
        # make sure it's at least 0.05
        amount = max(0.05, amount)
        return round(amount, 2)
    
    # if no stats, just pick a random amount
    return round(random.uniform(0.1, 1.0), 2)

def create_random_recipe(category_template, ingredient_to_units_map, roles_to_ingredients, 
                         classes_to_ingredients, amount_stats):
    """
    Create a random recipe that satisfies the category constraints
    """
    ingredients = []
    
    # get the constraints for this category
    constraints = category_template['type_constraints']
    
    # First, add ingredients for all required roles
    for role in constraints['must_have_roles']:
        if role in roles_to_ingredients:
            # pick a random ingredient with this role
            ing_name = random.choice(list(roles_to_ingredients[role]))
            
            # get possible units for this ingredient
            possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
            if possible_units:
                unit = random.choice(possible_units)
            else:
                unit = ''
            
            # get a sensible amount
            amount = get_sensible_amount(ing_name, unit, amount_stats)
            
            # add ingredient to list
            ingredients.append({
                'ingredient': ing_name,
                'amount': amount,
                'unit': unit
            })
    
    # Next, add ingredients for all required classes
    for ing_class in constraints['must_have_classes']:
        if ing_class in classes_to_ingredients:
            # pick a random ingredient with this class
            ing_name = random.choice(list(classes_to_ingredients[ing_class]))
            
            # check if this ingredient is already in the list
            already_added = False
            for existing_ing in ingredients:
                if existing_ing['ingredient'] == ing_name:
                    already_added = True
                    break
            
            # only add if not already there
            if not already_added:
                possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
                if possible_units:
                    unit = random.choice(possible_units)
                else:
                    unit = ''
                
                amount = get_sensible_amount(ing_name, unit, amount_stats)
                
                ingredients.append({
                    'ingredient': ing_name,
                    'amount': amount,
                    'unit': unit
                })
    
    # Create step_map (maps each ingredient to a step in the directions)
    step_map = {}
    
    # get the steps where ingredients are typically used
    action_steps = []
    for step in category_template['directions_struct']:
        if step['phase'] in ['mix', 'assemble', 'prep']:
            action_steps.append(step['id'])
    
    # if no action steps found, use all steps
    if not action_steps:
        action_steps = []
        for step in category_template['directions_struct']:
            action_steps.append(step['id'])
    
    # assign each ingredient to a random step
    for ing in ingredients:
        step_map[ing['ingredient']] = random.choice(action_steps)
    
    # create the recipe object
    recipe = {
        'ingredients': ingredients,
        'step_map': step_map
    }
    
    # remove duplicates and return
    return deduplicate_ingredients(recipe)

def evaluate_recipe(recipe, vectorizer, tfidf_matrix):
    """
    Evaluate how good a recipe is
    Returns three scores: coherence, simplicity, novelty
    """
    parts = []
    for ing in recipe['ingredients']:
        parts.append(ing['ingredient'])
    recipe_ingredients_str = ' '.join(parts)
    recipe_vec = vectorizer.transform([recipe_ingredients_str])
    cosine_sims = cosine_similarity(recipe_vec, tfidf_matrix)
    if cosine_sims.shape[1] > 0:
        max_sim = np.max(cosine_sims)
    else:
        max_sim = 0
    
    coherence_score = max_sim
    simplicity_score = len(recipe['ingredients'])
    novelty_score = 1 - max_sim
    
    return coherence_score, simplicity_score, novelty_score

def repair_recipe(recipe, category_template, ingredient_to_units_map, roles_to_ingredients,
                  classes_to_ingredients, amount_stats, ingredient_info):
    """
    Repair a recipe that doesn't satisfy constraints
    Add missing roles/classes until all requirements are met
    """
    constraints = category_template['type_constraints']
    MIN_INGREDIENTS = 3
    
    # Add ingredients until we have minimum
    current_ingredients = set()
    for ing in recipe['ingredients']:
        current_ingredients.add(ing['ingredient'])
    
    while len(recipe['ingredients']) < MIN_INGREDIENTS:
        # Try to add an ingredient that fills a missing requirement
        roles_present = set()
        for ing in recipe['ingredients']:
            roles_present.add(ingredient_info.get(ing['ingredient'], {}).get('role'))
        classes_present = set()
        for ing in recipe['ingredients']:
            classes_present.add(ingredient_info.get(ing['ingredient'], {}).get('class'))
        
        # Find missing roles
        missing_roles = []
        for r in constraints['must_have_roles']:
            if r not in roles_present:
                missing_roles.append(r)
        
        if missing_roles and missing_roles[0] in roles_to_ingredients:
            # Add ingredient with missing role
            candidates = []
            for ing in roles_to_ingredients[missing_roles[0]]:
                if ing not in current_ingredients:
                    candidates.append(ing)
            if candidates:
                ing_name = random.choice(candidates)
            else:
                ing_name = random.choice(list(roles_to_ingredients[missing_roles[0]]))
        else:
            # Just add any random ingredient
            candidates = []
            for ing in ingredient_info.keys():
                if ing not in current_ingredients:
                    candidates.append(ing)
            if candidates:
                ing_name = random.choice(candidates)
            else:
                break  # Can't add more
        
        # Add the ingredient
        possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
        unit = random.choice(possible_units) if possible_units else ''
        amount = get_sensible_amount(ing_name, unit, amount_stats)
        
        recipe['ingredients'].append({
            'ingredient': ing_name,
            'amount': amount,
            'unit': unit
        })
        current_ingredients.add(ing_name)
        
        # Add to step map
        action_steps = []
        for step in category_template['directions_struct']:
            if step['phase'] in ['mix', 'assemble', 'prep']:
                action_steps.append(step['id'])
        if not action_steps:
            action_steps = []
            for step in category_template['directions_struct']:
                action_steps.append(step['id'])
        recipe['step_map'][ing_name] = random.choice(action_steps)
    
    # Check and add missing roles/classes
    roles_present = set()
    for ing in recipe['ingredients']:
        roles_present.add(ingredient_info.get(ing['ingredient'], {}).get('role'))
    classes_present = set()
    for ing in recipe['ingredients']:
        classes_present.add(ingredient_info.get(ing['ingredient'], {}).get('class'))
    
    # Add missing roles
    for required_role in constraints['must_have_roles']:
        if required_role not in roles_present and required_role in roles_to_ingredients:
            candidates = []
            for ing in roles_to_ingredients[required_role]:
                if ing not in current_ingredients:
                    candidates.append(ing)
            if candidates:
                ing_name = random.choice(candidates)
            else:
                ing_name = random.choice(list(roles_to_ingredients[required_role]))
            
            possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
            unit = random.choice(possible_units) if possible_units else ''
            amount = get_sensible_amount(ing_name, unit, amount_stats)
            
            recipe['ingredients'].append({
                'ingredient': ing_name,
                'amount': amount,
                'unit': unit
            })
            current_ingredients.add(ing_name)
            
            action_steps = []
            for step in category_template['directions_struct']:
                if step['phase'] in ['mix', 'assemble', 'prep']:
                    action_steps.append(step['id'])
            if not action_steps:
                action_steps = []
                for step in category_template['directions_struct']:
                    action_steps.append(step['id'])
            recipe['step_map'][ing_name] = random.choice(action_steps)
            
            roles_present.add(required_role)
    
    # Add missing classes
    for required_class in constraints['must_have_classes']:
        if required_class not in classes_present and required_class in classes_to_ingredients:
            candidates = []
            for ing in classes_to_ingredients[required_class]:
                if ing not in current_ingredients:
                    candidates.append(ing)
            if candidates:
                ing_name = random.choice(candidates)
            else:
                ing_name = random.choice(list(classes_to_ingredients[required_class]))
            
            possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
            unit = random.choice(possible_units) if possible_units else ''
            amount = get_sensible_amount(ing_name, unit, amount_stats)
            
            recipe['ingredients'].append({
                'ingredient': ing_name,
                'amount': amount,
                'unit': unit
            })
            current_ingredients.add(ing_name)
            
            action_steps = []
            for step in category_template['directions_struct']:
                if step['phase'] in ['mix', 'assemble', 'prep']:
                    action_steps.append(step['id'])
            if not action_steps:
                action_steps = []
                for step in category_template['directions_struct']:
                    action_steps.append(step['id'])
            recipe['step_map'][ing_name] = random.choice(action_steps)
            
            classes_present.add(required_class)
    
    return deduplicate_ingredients(recipe)

def crossover_recipes(parent1, parent2):
    """
    Combine two parent recipes to create two offspring
    Uses single-point crossover
    Note: offspring may need repair to satisfy constraints
    """
    # get ingredient lists
    p1_ings = parent1['ingredients']
    p2_ings = parent2['ingredients']
    
    # perform single-point crossover
    min_len = min(len(p1_ings), len(p2_ings))
    
    if min_len > 1:
        # pick a crossover point
        cx_point = random.randint(1, min_len - 1)
        
        # create offspring ingredient lists
        o1_ings = p1_ings[:cx_point] + p2_ings[cx_point:]
        o2_ings = p2_ings[:cx_point] + p1_ings[cx_point:]
    else:
        # if lists are too short, just copy
        o1_ings = p1_ings[:]
        o2_ings = p2_ings[:]
    
    # create offspring recipe objects
    offspring1 = {'ingredients': o1_ings, 'step_map': {}}
    offspring2 = {'ingredients': o2_ings, 'step_map': {}}
    
    # inherit step_map from parents
    for ing in o1_ings:
        ing_name = ing['ingredient']
        # check if this ingredient came from p1
        found_in_p1 = False
        for i in p1_ings:
            if i['ingredient'] == ing_name:
                found_in_p1 = True
                break
        
        if found_in_p1:
            offspring1['step_map'][ing_name] = parent1['step_map'].get(ing_name)
        else:
            offspring1['step_map'][ing_name] = parent2['step_map'].get(ing_name)
    
    # same for offspring2
    for ing in o2_ings:
        ing_name = ing['ingredient']
        found_in_p2 = False
        for i in p2_ings:
            if i['ingredient'] == ing_name:
                found_in_p2 = True
                break
        
        if found_in_p2:
            offspring2['step_map'][ing_name] = parent2['step_map'].get(ing_name)
        else:
            offspring2['step_map'][ing_name] = parent1['step_map'].get(ing_name)
    
    # remove duplicates and return
    return deduplicate_ingredients(offspring1), deduplicate_ingredients(offspring2)

def check_recipe_constraints(recipe, category_template, ingredient_info):
    """
    Check if a recipe satisfies category constraints
    Returns (is_valid, penalty) where penalty is 0.0 if perfect, higher if worse
    
    This allows creativity while maintaining realism:
    - Hard minimum on ingredients (category-specific)
    - Soft requirements on roles/classes (75% required)
    - Penalties guide evolution, not hard blocks
    """
    constraints = category_template['type_constraints']
    cuisine = constraints.get('cuisine_path', 'unknown')
    
    # Category-specific minimums (reflects real dessert complexity)
    MIN_INGREDIENTS = {
        'fudge': 2,       # Can be very simple (chocolate + condensed milk)
        'bar': 3,         # Simple pressed bars
        'ice cream': 3,   # Dairy + sweetener + flavor
        'cookie': 3,      # Can be minimal (flour + fat + sugar)
        'brownie': 4,     # Richer than cookies
        'crisp': 4,       # Topping + fruit
        'cobbler': 4,     # Biscuit/cake + fruit
        'tart': 4,        # Crust + filling
        'pudding': 4,     # Multiple components
        'pie': 5,         # Crust + filling + multiple elements
        'cake': 5         # Complex structure
    }
    
    min_required = MIN_INGREDIENTS.get(cuisine, 3)
    penalty = 0.0
    
    # Hard constraint: minimum ingredients
    if len(recipe['ingredients']) < min_required:
        return False, 1.0  # Hard rejection
    
    # Soft constraint: roles (require 75% of must_have_roles)
    roles_present = set()
    for ing in recipe['ingredients']:
        info = ingredient_info.get(ing['ingredient'], {})
        if info.get('role'):
            roles_present.add(info['role'])
    
    required_roles = set(constraints['must_have_roles'])
    roles_satisfied = len(roles_present & required_roles)
    roles_required = len(required_roles)
    
    if roles_required > 0:
        role_coverage = roles_satisfied / roles_required
        if role_coverage < 0.75:  # Less than 75% coverage
            penalty += (0.75 - role_coverage) * 0.5  # Penalty up to 0.375
    
    # Soft constraint: classes (require 75% of must_have_classes)
    classes_present = set()
    for ing in recipe['ingredients']:
        info = ingredient_info.get(ing['ingredient'], {})
        if info.get('class'):
            classes_present.add(info['class'])
    
    required_classes = set(constraints['must_have_classes'])
    classes_satisfied = len(classes_present & required_classes)
    classes_required = len(required_classes)
    
    if classes_required > 0:
        class_coverage = classes_satisfied / classes_required
        if class_coverage < 0.75:  # Less than 75% coverage
            penalty += (0.75 - class_coverage) * 0.5  # Penalty up to 0.375
    
    # Valid if passed hard constraints (penalty is just a fitness adjustment)
    return True, penalty

def mutate_recipe(recipe, category_template, ingredient_to_units_map, roles_to_ingredients, 
                  classes_to_ingredients, amount_stats, ingredient_info, all_ingredients):
    """
    Make random changes to a recipe to introduce variety
    Ensures all category constraints are maintained
    """
    MIN_INGREDIENTS = 3
    # Mutation 1: Change an ingredient amount
    if random.random() < 0.2:  # 20% chance
        if recipe['ingredients']:  # if there are ingredients
            # pick a random ingredient
            idx = random.randrange(len(recipe['ingredients']))
            ing_to_mutate = recipe['ingredients'][idx]
            # change its amount
            recipe['ingredients'][idx]['amount'] = get_sensible_amount(
                ing_to_mutate['ingredient'], 
                ing_to_mutate['unit'],
                amount_stats
            )
    
    # Mutation 2: Add a new ingredient
    if random.random() < 0.1:  # 10% chance
        # get ingredients already in recipe
        current_ingredients = set()
        for ing in recipe['ingredients']:
            current_ingredients.add(ing['ingredient'])
        
        # find ingredients not in recipe
        possible_ingredients = []
        for ing in all_ingredients:
            if ing not in current_ingredients:
                possible_ingredients.append(ing)
        
        if possible_ingredients:
            # pick a random new ingredient
            ing_name = random.choice(possible_ingredients)
            
            # get unit and amount
            possible_units = list(ingredient_to_units_map.get(ing_name, ['']))
            if possible_units:
                unit = random.choice(possible_units)
            else:
                unit = ''
            
            amount = get_sensible_amount(ing_name, unit, amount_stats)
            
            # add to recipe
            recipe['ingredients'].append({
                'ingredient': ing_name,
                'amount': amount,
                'unit': unit
            })
            
            # assign to a step
            action_steps = []
            for step in category_template['directions_struct']:
                if step['phase'] in ['mix', 'assemble', 'prep']:
                    action_steps.append(step['id'])
            
            if not action_steps:
                action_steps = []
                for step in category_template['directions_struct']:
                    action_steps.append(step['id'])
            
            recipe['step_map'][ing_name] = random.choice(action_steps)
    
    # Mutation 3: Remove an ingredient
    if random.random() < 0.1:  # 10% chance
        if len(recipe['ingredients']) > MIN_INGREDIENTS:  # don't remove if at minimum
            # pick random ingredient to remove
            idx_to_remove = random.randrange(len(recipe['ingredients']))
            removed_ing = recipe['ingredients'][idx_to_remove]
            
            # Try removing and check if recipe still valid
            # Save the ingredient temporarily
            temp_ingredient = recipe['ingredients'].pop(idx_to_remove)
            if removed_ing['ingredient'] in recipe['step_map']:
                temp_step = recipe['step_map'].pop(removed_ing['ingredient'])
            else:
                temp_step = None
            
            # Check if recipe still satisfies constraints
            is_valid, penalty = check_recipe_constraints(recipe, category_template, ingredient_info)
            if not is_valid:
                # Recipe invalid (hard constraint violated), restore the ingredient
                recipe['ingredients'].insert(idx_to_remove, temp_ingredient)
                if temp_step:
                    recipe['step_map'][removed_ing['ingredient']] = temp_step
    
    # Mutation 4: Change which step an ingredient is used in
    if random.random() < 0.2:  # 20% chance
        if recipe['ingredients']:
            # pick random ingredient
            ing_to_remap = random.choice(recipe['ingredients'])
            ing_name = ing_to_remap['ingredient']
            
            # pick new random step
            action_steps = []
            for step in category_template['directions_struct']:
                if step['phase'] in ['mix', 'assemble', 'prep']:
                    action_steps.append(step['id'])
            
            if not action_steps:
                action_steps = []
                for step in category_template['directions_struct']:
                    action_steps.append(step['id'])
            
            recipe['step_map'][ing_name] = random.choice(action_steps)
    
    return recipe

def recipes_are_equal(r1, r2):
    """
    Check if two recipes have the same ingredients
    """
    ing1 = []
    for d in r1['ingredients']:
        ing1.append(d['ingredient'])
    ing1.sort()
    
    ing2 = []
    for d in r2['ingredients']:
        ing2.append(d['ingredient'])
    ing2.sort()
    return ing1 == ing2

def calculate_fitness(coherence, simplicity, novelty):
    """
    Calculate overall fitness score for sorting
    We want high coherence, low simplicity, and high novelty
    This is a multi-objective problem, but for sorting we use a weighted sum
    """
    # normalize simplicity (assume max 50 ingredients)
    simplicity_normalized = simplicity / 50.0
    
    # weighted sum (higher is better)
    fitness = (coherence * 0.4) - (simplicity_normalized * 0.3) + (novelty * 0.3)
    return fitness

def tournament_selection(population, k=3):
    """
    Select a recipe from the population using tournament selection
    Pick k random recipes and return the best one
    """
    tournament = random.sample(population, k)
    best = tournament[0]
    best_fitness = best['fitness']
    
    for recipe in tournament[1:]:
        if recipe['fitness'] > best_fitness:
            best = recipe
            best_fitness = recipe['fitness']
    
    return best['recipe']

def run_genetic_algorithm(category_template, vectorizer, tfidf_matrix, ingredient_to_units_map,
                          ingredient_info, roles_to_ingredients, classes_to_ingredients, 
                          amount_stats, all_ingredients, pop_size=50, generations=50):
    """
    Run the genetic algorithm to generate recipes
    """
    print(f"  Creating initial population of {pop_size} recipes...")
    population = []
    for i in range(pop_size):
        recipe = create_random_recipe(category_template, ingredient_to_units_map, 
                                      roles_to_ingredients, classes_to_ingredients, amount_stats)
        
        # Check constraints and get penalty
        is_valid, penalty = check_recipe_constraints(recipe, category_template, ingredient_info)
        
        # If hard constraints violated, repair it
        if not is_valid:
            recipe = repair_recipe(recipe, category_template, ingredient_to_units_map,
                                  roles_to_ingredients, classes_to_ingredients, 
                                  amount_stats, ingredient_info)
            _, penalty = check_recipe_constraints(recipe, category_template, ingredient_info)
        
        # evaluate the recipe
        coherence, simplicity, novelty = evaluate_recipe(recipe, vectorizer, tfidf_matrix)
        fitness = calculate_fitness(coherence, simplicity, novelty) - penalty  # Apply soft constraint penalty
        
        population.append({
            'recipe': recipe,
            'coherence': coherence,
            'simplicity': simplicity,
            'novelty': novelty,
            'fitness': fitness
        })
    
    for gen in range(generations):
        new_population = []
        
        population.sort(key=lambda x: x['fitness'], reverse=True)
        elite_count = max(1, int(pop_size * 0.1))
        for i in range(elite_count):
            new_population.append(copy.deepcopy(population[i]))
        
        while len(new_population) < pop_size:
            parent1 = tournament_selection(population)
            parent2 = tournament_selection(population)
            
            if random.random() < 0.8:  # 80% crossover rate
                offspring1, offspring2 = crossover_recipes(parent1, parent2)
            else:
                offspring1 = copy.deepcopy(parent1)
                offspring2 = copy.deepcopy(parent2)
            
            # Repair offspring if they violate HARD constraints (after crossover)
            is_valid1, _ = check_recipe_constraints(offspring1, category_template, ingredient_info)
            if not is_valid1:
                offspring1 = repair_recipe(offspring1, category_template, ingredient_to_units_map,
                                          roles_to_ingredients, classes_to_ingredients, 
                                          amount_stats, ingredient_info)
            
            is_valid2, _ = check_recipe_constraints(offspring2, category_template, ingredient_info)
            if not is_valid2:
                offspring2 = repair_recipe(offspring2, category_template, ingredient_to_units_map,
                                          roles_to_ingredients, classes_to_ingredients, 
                                          amount_stats, ingredient_info)
            
            # Mutation
            offspring1 = mutate_recipe(offspring1, category_template, ingredient_to_units_map,
                                       roles_to_ingredients, classes_to_ingredients, amount_stats,
                                       ingredient_info, all_ingredients)
            offspring2 = mutate_recipe(offspring2, category_template, ingredient_to_units_map,
                                       roles_to_ingredients, classes_to_ingredients, amount_stats,
                                       ingredient_info, all_ingredients)
            
            # Final check and repair after mutation (only if hard constraints violated)
            is_valid1, penalty1 = check_recipe_constraints(offspring1, category_template, ingredient_info)
            if not is_valid1:
                offspring1 = repair_recipe(offspring1, category_template, ingredient_to_units_map,
                                          roles_to_ingredients, classes_to_ingredients, 
                                          amount_stats, ingredient_info)
                _, penalty1 = check_recipe_constraints(offspring1, category_template, ingredient_info)
            
            is_valid2, penalty2 = check_recipe_constraints(offspring2, category_template, ingredient_info)
            if not is_valid2:
                offspring2 = repair_recipe(offspring2, category_template, ingredient_to_units_map,
                                          roles_to_ingredients, classes_to_ingredients, 
                                          amount_stats, ingredient_info)
                _, penalty2 = check_recipe_constraints(offspring2, category_template, ingredient_info)
            
            # Evaluate offspring
            coh1, sim1, nov1 = evaluate_recipe(offspring1, vectorizer, tfidf_matrix)
            fit1 = calculate_fitness(coh1, sim1, nov1) - penalty1  # Apply soft constraint penalty
            
            coh2, sim2, nov2 = evaluate_recipe(offspring2, vectorizer, tfidf_matrix)
            fit2 = calculate_fitness(coh2, sim2, nov2) - penalty2  # Apply soft constraint penalty
            
            # Add to new population
            new_population.append({
                'recipe': offspring1,
                'coherence': coh1,
                'simplicity': sim1,
                'novelty': nov1,
                'fitness': fit1
            })
            
            if len(new_population) < pop_size:
                new_population.append({
                    'recipe': offspring2,
                    'coherence': coh2,
                    'simplicity': sim2,
                    'novelty': nov2,
                    'fitness': fit2
                })
        
        # Remove duplicates
        unique_population = []
        for recipe_data in new_population:
            is_duplicate = False
            for existing in unique_population:
                if recipes_are_equal(recipe_data['recipe'], existing['recipe']):
                    is_duplicate = True
                    break
            if not is_duplicate:
                unique_population.append(recipe_data)
        
        # If we removed too many, fill with random recipes
        while len(unique_population) < pop_size:
            recipe = create_random_recipe(category_template, ingredient_to_units_map,
                                         roles_to_ingredients, classes_to_ingredients, amount_stats)
            coherence, simplicity, novelty = evaluate_recipe(recipe, vectorizer, tfidf_matrix)
            fitness = calculate_fitness(coherence, simplicity, novelty)
            unique_population.append({
                'recipe': recipe,
                'coherence': coherence,
                'simplicity': simplicity,
                'novelty': novelty,
                'fitness': fitness
            })
        
        population = unique_population
        
        # Print progress every 10 generations
        if (gen + 1) % 10 == 0:
            best_fitness = None
            for p in population:
                if best_fitness is None or p['fitness'] > best_fitness:
                    best_fitness = p['fitness']
            print(f"  Generation {gen + 1}/{generations}, Best fitness: {best_fitness:.4f}")
    
    # Return the diverse set of best recipes (top 50), sorted by fitness
    population.sort(key=lambda x: x['fitness'], reverse=True)
    best_recipes = population[:50]
    
    # Print summary
    print(f"  Final best fitness: {best_recipes[0]['fitness']:.4f}")
    print(f"  Best recipe has {best_recipes[0]['simplicity']} ingredients")
    print(f"  Coherence: {best_recipes[0]['coherence']:.4f}, Novelty: {best_recipes[0]['novelty']:.4f}")
    
    return best_recipes

def save_recipes(all_results, category_templates):
    """
    Save the generated recipes to a JSON file with rankings and fun names
    """
    output_data = {}
    
    # process each category
    for category in all_results:
        results = all_results[category]
        category_output = []
        template = category_templates[category]
        
        # Track used names for this category to ensure uniqueness
        used_names = set()
        
        # Sort results by fitness to ensure proper ranking
        results_sorted = sorted(results, key=lambda x: x['fitness'], reverse=True)
        
        # process each recipe and add rank
        for rank, res in enumerate(results_sorted, start=1):
            recipe_obj = res['recipe']
            
            # Generate a fun name for this recipe
            recipe_name = generate_recipe_name(recipe_obj, category, used_names)
            
            # copy the directions template
            directions = copy.deepcopy(template['directions_struct'])
            
            # create map from step id to step object
            step_id_map = {}
            for step in directions:
                step_id_map[step['id']] = step
            
            # add ingredients to the appropriate steps
            for ing in recipe_obj['ingredients']:
                ing_name = ing['ingredient']
                step_id = recipe_obj['step_map'].get(ing_name)
                
                if step_id and step_id in step_id_map:
                    step_id_map[step_id]['uses'].append(ing_name)
            
            # create final recipe structure with name
            final_recipe = {
                'name': recipe_name,
                'ingredients': recipe_obj['ingredients'],
                'directions': directions
            }
            
            # calculate balanced fitness for reference
            fitness_score = res.get('fitness', calculate_fitness(res['coherence'], res['simplicity'], res['novelty']))
            
            # add to output with scores and rank
            recipe_entry = {
                'rank': rank,
                'recipe': final_recipe,
                'coherence_score': res['coherence'],
                'simplicity_score': res['simplicity'],
                'novelty_score': res['novelty'],
                'fitness_score': round(fitness_score, 4)
            }
            
            # Mark the best recipe (rank 1) with special key
            if rank == 1:
                print(f"  Best {category} recipe (Rank 1): '{recipe_name}'")
                print(f"    {len(recipe_obj['ingredients'])} ingredients, fitness={fitness_score:.4f}")
            
            category_output.append(recipe_entry)
        
        output_data[category] = category_output
    
    # save to file
    f = open('generated_recipes_by_category.json', 'w')
    json.dump(output_data, f, indent=4)
    f.close()
    
    print("\n" + "="*60)
    print("Saved generated recipes to generated_recipes_by_category.json")
    print(f"Total categories: {len(output_data)}")
    total_recipes = sum(len(recipes) for recipes in output_data.values())
    print(f"Total recipes generated: {total_recipes}")
    print(f"Recipes per category: {total_recipes // len(output_data) if output_data else 0}")
    print("="*60)

def main():
    recipe_data = load_data('desserts_data.json')
    
    f = open('category_templates.json', 'r')
    category_templates = json.load(f)
    f.close()
    
    all_results = {}
    
    for category in category_templates:
        template = category_templates[category]
        print(f"\n--- Generating recipes for category: {category} ---")
        
        category_data = recipe_data[recipe_data['cuisine_path'] == category]
        
        if category_data.empty:
            print(f"No data for category: {category}, skipping.")
            continue
        
        # preprocess the full dataset to get mappings
        print(f"Preprocessing data for {category}...")
        (all_ingredients_list, all_units, all_actions, _, _, 
         ingredient_to_units_map, ingredient_info, roles_to_ingredients, 
         classes_to_ingredients, amount_stats) = preprocess_data(recipe_data)
        
        # create category-specific TF-IDF matrix
        print(f"Creating TF-IDF matrix for {category}...")
        corpus = []
        for ingredients in category_data['ingredients']:
            names = []
            for ing in ingredients:
                names.append(ing['ingredient'])
            ingredient_string = ' '.join(names)
            corpus.append(ingredient_string)
        
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(corpus)
        
        # run the genetic algorithm
        print(f"Running genetic algorithm for {category}...")
        results = run_genetic_algorithm(
            template, vectorizer, tfidf_matrix, ingredient_to_units_map,
            ingredient_info, roles_to_ingredients, classes_to_ingredients,
            amount_stats, all_ingredients_list, pop_size=50, generations=50
        )
        
        print(f"Generated {len(results)} recipes for {category}.")
        
        all_results[category] = results
    
    print("\nSaving all recipes...")
    save_recipes(all_results, category_templates)

if __name__ == "__main__":
    main()
