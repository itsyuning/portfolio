import pandas as pd
import json
import os
from openai import OpenAI
from dotenv import load_dotenv
import logging
from tqdm import tqdm
import re

load_dotenv()
API_KEY = os.getenv("OPENROUTER_API_KEY")
MODEL_NAME = "openai/gpt-4o" 
INPUT_CSV_PATH = 'data/desserts_1.csv'
OUTPUT_JSON_PATH = 'desserts_data.json'
RECIPE_PROCESSING_LIMIT = 5 

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

if not API_KEY:
    logging.error("OPENROUTER_API_KEY environment variable not set.")
    exit()

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=API_KEY,
)

def get_target_json_structure_example():
    """Provides a JSON structure example for the LLM prompt."""
    return {
        "recipe_name": "Example Apple Pie",
        "prep_time": 30,
        "cook_time": 60,
        "total_time": 90,
        "servings": 8,
        "ingredients": [
            {"amount": 8.0, "unit": "", "ingredient": "apples", "class": "fruit", "role": "bulk"},
            {"amount": 0.5, "unit": "cup", "ingredient": "butter", "class": "fat", "role": "fat"},
            {"amount": 0.75, "unit": "cup", "ingredient": "white sugar", "class": "sweetener", "role": "sweetener"},
            {"amount": 3.0, "unit": "tbsp", "ingredient": "flour", "class": "grain", "role": "structure"},
            {"amount": 0.25, "unit": "cup", "ingredient": "water", "class": "liquid", "role": "moisture"},
            {"amount": 1.0, "unit": "package", "ingredient": "pie crust", "class": "pastry", "role": "structure"}
        ],
        "rating": 4.5,
        "cuisine_path": "/Desserts/Pies/Apple Pie",
        "nutrition": {
            "total_fat": 19.0, "saturated_fat": 9.0, "cholesterol": 0.031,
            "sodium": 0.124, "total_carbohydrate": 52.0, "dietary_fiber": 3.0,
            "protein": 2.0, "calories": 411
        },
        "directions_text": [
            "Preheat oven to 425°F (220°C).",
            "Melt butter in a saucepan.",
            "Combine sugars and add to butter.",
            "Place apples in pie crust.",
            "Pour sugar mixture over apples.",
            "Bake for 45-55 minutes."
        ]
    }

def clean_text(text):
    """Cleans a string by removing excess whitespace and non-UTF8 characters."""
    if not isinstance(text, str):
        return text
    text = text.strip()
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[\x00-\x1F\x7F]', '', text)
    return text.encode('utf-8', 'ignore').decode('utf-8')

def convert_time_to_minutes(time_str):
    """Converts a time string (e.g., '1 hrs 30 mins') to total minutes."""
    if not isinstance(time_str, str):
        return None
    
    minutes = 0
    time_str = time_str.lower()

    # Find hours
    hours_match = re.search(r'(\d+)\s*hrs?', time_str)
    if hours_match:
        minutes += int(hours_match.group(1)) * 60

    # Find minutes
    mins_match = re.search(r'(\d+)\s*mins?', time_str)
    if mins_match:
        minutes += int(mins_match.group(1))

    return minutes if minutes > 0 else None

def manual_clean_dataframe(df):
    """Applies a series of manual cleaning steps to the dataframe."""
    logging.info("Starting manual data cleaning...")

    # Clean text fields
    for col in ['recipe_name', 'ingredients', 'directions', 'nutrition']:
        if col in df.columns:
            df[col] = df[col].apply(clean_text)

    # Convert time columns to minutes
    for col in ['prep_time', 'cook_time', 'total_time']:
        if col in df.columns:
            df[col] = df[col].apply(convert_time_to_minutes)
    
    # Fill missing values
    df.fillna('N/A', inplace=True)
    
    logging.info("Manual data cleaning complete.")
    return df

def create_prompt(recipe_data):
    """Creates a detailed prompt for the LLM to transform recipe data."""
    
    target_structure = get_target_json_structure_example()

    prompt = f"""
    You are a recipe data normalization expert. Your task is to transform raw recipe data into a structured JSON format.
    You need to handle messy data, parse ingredient strings into components (amount, unit, name), classify ingredients, and structure directions and nutrition information.
    You must also handle synonyms and normalize ingredient names (e.g., 'all-purpose flour' and 'flour' should be consistent).

    Here is the raw data for a recipe:
    - Recipe Name: {recipe_data.get('recipe_name', 'N/A')}
    - Preparation Time: {recipe_data.get('prep_time', 'N/A')}
    - Cooking Time: {recipe_data.get('cook_time', 'N/A')}
    - Total Time: {recipe_data.get('total_time', 'N/A')}
    - Servings: {recipe_data.get('servings', 'N/A')}
    - Ingredients String: "{recipe_data.get('ingredients', 'N/A')}"
    - Directions String: "{recipe_data.get('directions', 'N/A')}"
    - Rating: {recipe_data.get('rating', 'N/A')}
    - Cuisine Path: {recipe_data.get('cuisine_path', 'N/A')}
    - Nutrition String: "{recipe_data.get('nutrition', 'N/A')}"

    Please transform this into a JSON object with the following structure.
    - Convert time fields to integers representing minutes.
    - Parse the ingredients string into a list of objects, each containing amount, unit, ingredient, class and role.
    - Split the directions string into a list of individual steps.
    - Parse the nutrition string into a JSON object with keys for each nutrient.

    INGREDIENT CLASSIFICATION GUIDELINES:
    For each ingredient, you must assign both a "class" and a "role":

    INGREDIENT CLASSES (select the most appropriate):
    - "fruit": apples, berries, bananas, citrus, etc.
    - "vegetable": pumpkin, sweet potato, carrots, etc.
    - "dairy": milk, cream, butter, cheese, yogurt, sour cream
    - "egg": eggs, egg whites, egg yolks
    - "fat": butter, oil, shortening, lard, margarine
    - "grain": flour, oats, cornmeal, wheat, rice
    - "sweetener": sugar (white, brown, powdered), honey, maple syrup, molasses, corn syrup
    - "chocolate": cocoa powder, chocolate chips, melted chocolate, cacao
    - "nut": almonds, walnuts, pecans, peanuts, cashews, hazelnuts
    - "spice": cinnamon, nutmeg, ginger, cloves, vanilla, salt, pepper
    - "liquid": water, milk, juice, coffee, tea
    - "leavening": baking powder, baking soda, yeast
    - "thickener": cornstarch, gelatin, pectin, tapioca
    - "pastry": pie crust, puff pastry, phyllo dough
    - "candy": chocolate chips, M&Ms, sprinkles, candy pieces


    INGREDIENT ROLES (select the most appropriate):
    - "bulk": main volume ingredient (apples in apple pie, flour in cake)
    - "fat": provides richness and moisture (butter, oil)
    - "sweetener": provides sweetness (sugar, honey)
    - "structure": provides texture/body (flour, eggs, gelatin)
    - "moisture": provides liquid (water, milk, juice)
    - "leavening": makes baked goods rise (baking powder, yeast)
    - "flavoring": primary flavoring (vanilla, chocolate, spices)
    - "texture": adds textural element (nuts, chocolate chips)
    - "binding": holds ingredients together (eggs, syrup)
    - "seasoning": adds flavor (salt, pepper)

    Here is an example of the target JSON structure:
    {json.dumps(target_structure, indent=2)}

    Now, provide the transformed JSON for the recipe data provided above.
    The output must be only the JSON object, without any surrounding text or markdown.
    """
    return prompt

def transform_recipe(recipe_row):
    """
    Transforms a single recipe from a CSV row to a structured dictionary using an LLM.
    """
    prompt = create_prompt(recipe_row.to_dict())
    
    try:
        completion = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": "You are a data transformation assistant that outputs JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2, # Lower temperature for more deterministic output
            response_format={"type": "json_object"},
        )
        
        response_content = completion.choices[0].message.content
        return json.loads(response_content)
        
    except Exception as e:
        logging.error(f"Error processing recipe '{recipe_row['recipe_name']}': {e}")
        return None

def main():
    """Reads CSV, processes recipes, and saves to JSON."""
    logging.info(f"Loading recipes from {INPUT_CSV_PATH}...")
    try:
        df = pd.read_csv(INPUT_CSV_PATH)
    except FileNotFoundError:
        logging.error(f"Input file not found: {INPUT_CSV_PATH}")
        return

    df = manual_clean_dataframe(df)

    if RECIPE_PROCESSING_LIMIT is not None:
        df = df.head(RECIPE_PROCESSING_LIMIT)
        logging.info(f"Processing a limited number of recipes: {RECIPE_PROCESSING_LIMIT}")

    transformed_recipes = []
    
    for _, row in tqdm(df.iterrows(), total=len(df), desc="Transforming Recipes"):
        transformed_recipe = transform_recipe(row)
        if transformed_recipe:
            transformed_recipes.append(transformed_recipe)

    logging.info(f"Successfully transformed {len(transformed_recipes)} recipes.")

    if transformed_recipes:
        logging.info(f"Saving transformed recipes to {OUTPUT_JSON_PATH}...")
        with open(OUTPUT_JSON_PATH, 'w') as f:
            json.dump(transformed_recipes, f, indent=2)
        logging.info("Done.")
    else:
        logging.warning("No recipes were transformed.")

if __name__ == "__main__":
    main()

