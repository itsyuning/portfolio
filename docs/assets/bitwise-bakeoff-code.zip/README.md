# The Great Bitwise Bakeoff

A genetic algorithm system for generating novel dessert recipes using multi-objective optimization.

---

## System Requirements

### Prerequisites
- **Python:** 3.8 or higher

### Required Python Packages
- `pandas` (>=2.3.0) - Data manipulation
- `numpy` (>=2.3.0) - Numerical operations
- `scikit-learn` (>=1.7.0) - Machine learning utilities
- `openai` (>=2.2.0) - LLM API client
- `python-dotenv` (>=1.1.0) - Environment variable management
- `tqdm` (>=4.67.0) - Progress bars

### API Requirements
- **OpenRouter API Key** (for `process_recipes.py`)
  - Sign up at [openrouter.ai](https://openrouter.ai)
  - Provides access to GPT-4o for ingredient classification

---

## Installation

### 1. Access the main dir
```bash
cd /path/to/The-Great-Bitwise-Bakeoff
```

### 2. Create a virtual environment (recommended)
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up environment variables
Create a `.env` file in the project root:
```bash
OPENROUTER_API_KEY=your_api_key_here
```

---

## Running the System

### Step 1: Process Raw Recipe Data
Transforms CSV data into structured JSON with classified ingredients:
```bash
python process_recipes.py
```
- **Input:** `data/desserts_1.csv`
- **Output:** `desserts_data.json`
- **Note:** Uses OpenRouter API (costs apply - already cleaned output exists.)

### Step 2: Generate Novel Recipes
Runs the genetic algorithm to create new recipes:
```bash
python recipe_generator.py
```
- **Input:** `desserts_data.json`, `category_templates.json`
- **Output:** `generated_recipes_by_category.json`
- **Duration:** ~10-15 minutes (50 generations × 11 categories)

---

## Configuration

### `process_recipes.py` Settings
Edit these variables at the top of the file:
```python
MODEL_NAME = "openai/gpt-4o"              # LLM model to use
INPUT_CSV_PATH = 'data/desserts_1.csv'    # Input data file
OUTPUT_JSON_PATH = 'desserts_data.json'   # Output file
RECIPE_PROCESSING_LIMIT = 5               # Number of recipes to process (None = all)
```

### `recipe_generator.py` Settings
Edit these constants in the file:
```python
POPULATION_SIZE = 50        # Recipes per generation
NUM_GENERATIONS = 50        # Evolution iterations
NUM_OUTPUT_RECIPES = 50     # Top recipes to output per category
```

---

## Project Files

| **File**                              | **Description**                                                                                      |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| `process_recipes.py`                  | Transforms raw CSV recipe data into structured JSON using LLM-based ingredient classification        |
| `recipe_generator.py`                 | Genetic algorithm that evolves novel dessert recipes by combining ingredients with category templates |
| `desserts_data.json`                  | Cleaned and structured training data (260 recipes with classified ingredients)                       |
| `generated_recipes_by_category.json`  | Output file containing 550 AI-generated recipes ranked by fitness scores                             |
| `category_templates.json`             | Cooking instruction templates for 11 dessert categories (pie, cake, cookie, etc.)                    |
| `data/desserts_1.csv`                 | Raw input data from AllRecipes.com (Kaggle dataset)                                                  |
| `requirements.txt`                    | Python dependencies for the project                                                                  |

---

### Ingredient Roles and Classes

| **Role**    | Examples          |
| ----------- | ----------------- |
| `fat`       | butter, oil       |
| `sweetener` | sugar, honey      |
| `structure` | flour, eggs       |
| `moisture`  | milk, water       |
| `flavoring` | vanilla, extracts |
| `seasoning` | salt, spices      |
| `bulk`      | fruits, nuts      |

| **Class**   | **Examples**           |
| ----------- | ---------------------- |
| `grain`     | flour, oats            |
| `dairy`     | milk, cream            |
| `fruit`     | apples, berries        |
| `fat`       | butter, oil            |
| `sweetener` | sugar                  |
| `chocolate` | cocoa, chocolate chips |
| `nut`       | almonds, walnuts       |
| `spice`     | cinnamon, nutmeg       |

---

### Category Templates (Fixed Instructions)

Cooking instructions were **template-based** per dessert type.  
The GA only assigned ingredients to steps, not the actions themselves.  

| **Category**  | **Required Roles**                             | **Typical Key Verbs / Instructions** |
| ------------- | ---------------------------------------------- | ------------------------------------ |
| **Pie**       | fat, fruit, grain, pastry, sweetener           | preheat → combine → pour → bake      |
| **Cake**      | structure, fat, sweetener, moisture, flavoring | preheat → mix → pour → bake → cool   |
| **Cookie**    | fat, sweetener, structure, flavoring           | mix → add → bake → cool              |
| **Cobbler**   | fruit, sweetener, structure, fat               | preheat → mix → pour → bake          |
| **Crisp**     | fruit, fat, sweetener, grain                   | preheat → mix → sprinkle → bake      |
| **Tart**      | fat, pastry, sweetener, flavoring              | preheat → combine → pour → bake      |
| **Pudding**   | milk, structure, sweetener, flavoring          | stir → combine → heat → chill        |
| **Ice Cream** | dairy, sweetener, flavoring, fat               | mix → churn → chill → serve          |
| **Brownie**   | structure, fat, chocolate, sweetener           | mix → pour → bake → cool             |
| **Bar**       | structure, fat, sweetener, flavoring           | mix → bake → cool → cut              |
| **Fudge**     | sweetener, fat, flavoring                      | mix → heat → stir → cool             |


