import re
import sys
import os
from dataclasses import dataclass
import requests
import stanza
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast


# Holds the current state while solving
@dataclass
class CSPState:
    grid: list       # the NxN word grid
    used_words: set  # words we've already used
    used_lemmas: set # word roots we've used
    
    def copy(self):
        return CSPState(
            grid=[row[:] for row in self.grid],
            used_words=self.used_words.copy(),
            used_lemmas=self.used_lemmas.copy()
        )


# Checks if words/rows satisfy our constraints
class ConstraintChecker:
    
    def __init__(self, nlp, perplexity_model, perplexity_tokenizer):
        self.nlp = nlp
        self.perplexity_model = perplexity_model
        self.perplexity_tokenizer = perplexity_tokenizer
    
    def get_lemma(self, word):
        try:
            doc = self.nlp(word)
            if doc.sentences and doc.sentences[0].words:
                return doc.sentences[0].words[0].lemma.lower()
        except:
            pass
        return word.lower()
    
    def get_pos_tags(self, words):
        try:
            doc = self.nlp(' '.join(words))
            tags = []
            for sent in doc.sentences:
                for w in sent.words:
                    tags.append(w.upos)
            return tags
        except:
            return []
    
    def calculate_perplexity(self, text):
        try:
            encodings = self.perplexity_tokenizer(text, return_tensors='pt')
            max_len = self.perplexity_model.config.n_positions
            
            if encodings.input_ids.shape[1] > max_len:
                encodings.input_ids = encodings.input_ids[:, :max_len]
            
            with torch.no_grad():
                outputs = self.perplexity_model(**encodings, labels=encodings.input_ids)
                return torch.exp(outputs.loss).item()
        except:
            return 0.0
    
    def check_uniqueness(self, new_words, state):
        for word in new_words:
            w_lower = word.lower()
            lemma = self.get_lemma(word)
            
            if w_lower in state.used_words:
                return False, f"'{word}' repeated"
            if lemma in state.used_lemmas:
                return False, f"root '{lemma}' repeated"
        
        new_lower = [w.lower() for w in new_words]
        if len(set(new_lower)) != len(new_lower):
            return False, "has duplicates"
        
        new_lemmas = [self.get_lemma(w) for w in new_words]
        if len(set(new_lemmas)) != len(new_lemmas):
            return False, "has duplicate roots"
        
        return True, ""
    
    def check_grammar(self, words, is_complete=True):
        if len(words) < 2:
            return True, ""
        
        try:
            tags = self.get_pos_tags(words)
            if len(tags) != len(words):
                return True, ""
            
            if is_complete and tags[-1] in {'DET', 'ADP'}:
                return False, f"bad ending"
            
            return True, ""
        except:
            return True, ""
    
    def check_perplexity(self, words, threshold=100000):
        text = ' '.join(words)
        ppl = self.calculate_perplexity(text)
        
        if ppl > threshold:
            return False, "perplexity too high"
        return True, ""
    
    def check_last_row(self, words):
        if len(words) < 3:
            return True, ""
        
        try:
            tags = self.get_pos_tags(words)
            if len(tags) != len(words):
                return True, ""
            
            has_verb = any(t in {'VERB', 'AUX'} for t in tags)
            has_noun = any(t in {'NOUN', 'PROPN', 'PRON'} for t in tags)
            has_func = any(t in {'DET', 'ADP', 'AUX'} for t in tags)
            
            if not has_verb and not (has_noun and has_func):
                return False, "not a sentence"
            
            if tags[-1] in {'DET', 'ADP'}:
                return False, "bad ending"
            
            return True, ""
        except:
            return True, ""


# Generates candidate words using Ollama
class DomainGenerator:
    
    def __init__(self, model_name="llama3.2"):
        self.model_name = model_name
        self.api_url = "http://localhost:11434/api/generate"
    
    def call_llm(self, prompt, temperature=0.8):
        try:
            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "top_p": 0.9,
                    "num_ctx": 4096
                }
            }
            
            resp = requests.post(self.api_url, json=payload, timeout=45)
            
            if resp.status_code == 200:
                return resp.json().get("response", "")
            else:
                print(f"Ollama error: {resp.status_code}", file=sys.stderr)
                return None
                
        except requests.exceptions.ConnectionError:
            print("Can't connect to Ollama", file=sys.stderr)
            return None
        except Exception as e:
            print(f"LLM error: {e}", file=sys.stderr)
            return None
    
    def extract_sequences(self, text, word_count):
        text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)
        text = re.sub(r'["""\'`*_#\[\]]', '', text)
        
        sequences = []
        for line in text.strip().split('\n'):
            line = line.strip()
            
            if not line or ':' in line[:15]:
                continue
            
            words = re.findall(r'\b[a-zA-Z]+\b', line)
            
            if len(words) == word_count:
                sequences.append([w.lower() for w in words])
            elif len(words) > word_count and len(words) <= word_count + 2:
                sequences.append([w.lower() for w in words[:word_count]])
        
        return sequences
    
    def generate_first_row(self, theme, size, num_candidates=5):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(script_dir, 'prompt_first_row.txt')
        
        with open(prompt_path, 'r') as f:
            template = f.read()
        
        prompt = template.format(
            num_candidates=num_candidates,
            theme=theme,
            size=size
        )

        candidates = []
        attempts = 0
        
        while len(candidates) < num_candidates and attempts < 3:
            attempts += 1
            output = self.call_llm(prompt, temperature=0.85 + (attempts * 0.05))
            
            if output:
                seqs = self.extract_sequences(output, size)
                
                for seq in seqs:
                    if len(set(seq)) != len(seq):
                        continue
                    
                    if tuple(seq) not in [tuple(c) for c in candidates]:
                        candidates.append(seq)
                    
                    if len(candidates) >= num_candidates:
                        break
        
        return candidates
    
    def generate_row_completion(self, theme, size, row_idx, prefix, context, used, num_candidates=5):
        words_needed = size - len(prefix)
        
        if words_needed <= 0:
            return [[]]
        
        prefix_str = ' '.join(prefix)
        used_str = ', '.join(sorted(used)[:25])
        
        is_last = (row_idx == size - 1)
        last_note = "\n This is the LAST line - make it a complete sentence!" if is_last else ""
        last_rule = "Must form a complete sentence" if is_last else "Should flow naturally"
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        prompt_path = os.path.join(script_dir, 'prompt_row_completion.txt')
        
        with open(prompt_path, 'r') as f:
            template = f.read()
        
        prompt = template.format(
            row_number=row_idx + 1,
            theme=theme,
            last_row_note=last_note,
            context=context,
            prefix_str=prefix_str,
            num_candidates=num_candidates,
            words_needed=words_needed,
            used_list=used_str,
            last_row_rule=last_rule
        )

        candidates = []
        attempts = 0
        prefix_lower = [w.lower() for w in prefix]
        
        while len(candidates) < num_candidates and attempts < 3:
            attempts += 1
            output = self.call_llm(prompt, temperature=0.8 + (attempts * 0.05))
            
            if output:
                partial = self.extract_sequences(output, words_needed)
                full = self.extract_sequences(output, size)
                all_seqs = partial + full
                
                for seq in all_seqs:
                    if len(seq) > words_needed:
                        seq_lower = [w.lower() for w in seq]
                        if seq_lower[:len(prefix_lower)] == prefix_lower:
                            seq = seq[len(prefix_lower):]
                    
                    if len(seq) != words_needed:
                        continue
                    
                    seq_set = {w.lower() for w in seq}
                    prefix_set = {w.lower() for w in prefix}
                    if prefix_set & seq_set:
                        continue
                    
                    if len(seq_set) != len(seq):
                        continue
                    
                    if tuple(seq) not in [tuple(c) for c in candidates]:
                        candidates.append(seq)
                    
                    if len(candidates) >= num_candidates:
                        break
        
        return candidates


# Uses backtracking to find a valid square poem
class SquarePoemCSP:
    
    def __init__(self, theme, size=6, model_name="llama3.2", max_candidates=8, max_backtracks=200):
        self.theme = theme
        self.size = size
        self.max_candidates = max_candidates
        self.max_backtracks = max_backtracks
        self.backtrack_count = 0
        
        print("Setting up...", file=sys.stderr)
        print(f"  Theme: {theme}", file=sys.stderr)
        print(f"  Size: {size}x{size}", file=sys.stderr)
        print(f"  Model: {model_name}", file=sys.stderr)
        print("\nLoading models...", file=sys.stderr)
        
        try:
            nlp = stanza.Pipeline('en', processors='tokenize,pos,lemma', verbose=False)
            print("  ✓ Stanza loaded", file=sys.stderr)
        except Exception as e:
            print(f"  ✗ Stanza failed", file=sys.stderr)
            sys.exit(1)
        
        try:
            tokenizer = GPT2TokenizerFast.from_pretrained('gpt2')
            model = GPT2LMHeadModel.from_pretrained('gpt2')
            model.eval()
            print("  ✓ GPT-2 loaded", file=sys.stderr)
        except Exception as e:
            print(f"  ✗ GPT-2 failed", file=sys.stderr)
            sys.exit(1)
        
        self.checker = ConstraintChecker(nlp, model, tokenizer)
        self.generator = DomainGenerator(model_name)
        
        print("\n" + "-"*50, file=sys.stderr)
    
    def solve(self):
        print("Starting search...", file=sys.stderr)
        print("-"*50 + "\n", file=sys.stderr)
        
        initial = CSPState(
            grid=[[None for _ in range(self.size)] for _ in range(self.size)],
            used_words=set(),
            used_lemmas=set()
        )
        
        self.backtrack_count = 0
        result = self.backtrack(initial, row=0)
        
        if result:
            print(f"\n{'='*50}", file=sys.stderr)
            print(f"✓ Found solution!", file=sys.stderr)
            print(f"  Backtracks: {self.backtrack_count}", file=sys.stderr)
            print(f"{'-'*50}\n", file=sys.stderr)
        else:
            print(f"\n{'-'*50}", file=sys.stderr)
            print(f"✗ No solution", file=sys.stderr)
            print(f"  Backtracks: {self.backtrack_count}", file=sys.stderr)
        
        return result
    
    def backtrack(self, state, row):
        if row == self.size:
            return state.grid
        
        if self.backtrack_count > self.max_backtracks:
            print(f"  [Hit limit: {self.max_backtracks}]", file=sys.stderr)
            return None
        
        indent = "  " * row
        
        # get prefix from symmetry
        prefix = []
        for col in range(row):
            word = state.grid[col][row]
            if word is None:
                print(f"{indent}ERROR at [{col}][{row}]", file=sys.stderr)
                return None
            prefix.append(word)
        
        if prefix:
            print(f"{indent}Row {row}: prefix = '{' '.join(prefix)}'", file=sys.stderr)
        else:
            print(f"{indent}Row {row}: (first row)", file=sys.stderr)
        
        context = self.build_context(state.grid, row)
        
        if row == 0:
            domain = self.generator.generate_first_row(self.theme, self.size, self.max_candidates)
        else:
            domain = self.generator.generate_row_completion(
                self.theme, self.size, row, prefix,
                context, state.used_words, self.max_candidates
            )
        
        if not domain:
            print(f"{indent}  ✗ No candidates", file=sys.stderr)
            self.backtrack_count += 1
            return None
        
        print(f"{indent}  Got {len(domain)} candidates", file=sys.stderr)
        
        for i, completion in enumerate(domain):
            full_row = prefix + completion
            
            if len(full_row) != self.size:
                continue
            
            print(f"{indent}  [{i+1}/{len(domain)}] {' '.join(full_row)}", file=sys.stderr)
            
            ok, reason = self.checker.check_uniqueness(completion, state)
            if not ok:
                print(f"{indent}      ✗ {reason}", file=sys.stderr)
                continue
            
            ok, reason = self.checker.check_grammar(full_row)
            if not ok:
                print(f"{indent}      ✗ {reason}", file=sys.stderr)
                continue
            
            if row == self.size - 1:
                ok, reason = self.checker.check_last_row(full_row)
                if not ok:
                    print(f"{indent}      ✗ {reason}", file=sys.stderr)
                    continue
            
            new_state = state.copy()
            
            for j, word in enumerate(full_row):
                new_state.grid[row][j] = word
            
            for i in range(self.size):
                new_state.grid[i][row] = full_row[i]
            
            for word in completion:
                new_state.used_words.add(word.lower())
                new_state.used_lemmas.add(self.checker.get_lemma(word))
            
            print(f"{indent}      ✓ ok", file=sys.stderr)
            
            result = self.backtrack(new_state, row + 1)
            
            if result is not None:
                return result
            
            print(f"{indent}      ↩ backtracking...", file=sys.stderr)
            self.backtrack_count += 1
        
        return None
    
    def build_context(self, grid, row):
        lines = []
        for i in range(row):
            r = grid[i]
            if all(w is not None for w in r):
                lines.append(f"Line {i+1}: {' '.join(r)}")
        return '\n'.join(lines) if lines else "(First line)"
    
    def verify(self, grid):
        for i in range(self.size):
            for j in range(self.size):
                if grid[i][j] != grid[j][i]:
                    return False
        return True
    
    def format_output(self, grid):
        lines = []
        
        CYAN = '\033[96m'
        BOLD = '\033[1m'
        RESET = '\033[0m'
        
        col_widths = []
        for col in range(self.size):
            max_w = max(len(grid[r][col]) for r in range(self.size))
            col_widths.append(max(max_w + 2, 10))
        
        lines.append("\n" + "-" * 70)
        lines.append(f"Theme: {self.theme}".center(70))
        lines.append("-" * 70)
        lines.append("")
        
        top = "┌" + "┬".join(["─" * w for w in col_widths]) + "┐"
        lines.append(top)
        
        for row_idx, row in enumerate(grid):
            cells = []
            for col_idx, word in enumerate(row):
                if row_idx == col_idx:
                    colored = f"{CYAN}{BOLD}{word}{RESET}"
                    pad = col_widths[col_idx] - len(word)
                    left = pad // 2
                    right = pad - left
                    cell = " " * left + colored + " " * right
                else:
                    cell = word.center(col_widths[col_idx])
                cells.append(cell)
            
            lines.append("│" + "│".join(cells) + "│")
            
            if row_idx < self.size - 1:
                mid = "├" + "┼".join(["─" * w for w in col_widths]) + "┤"
                lines.append(mid)
        
        bottom = "└" + "┴".join(["─" * w for w in col_widths]) + "┘"
        lines.append(bottom)
        
        lines.append("")
        lines.append("-" * 70)
        lines.append("✓ SYMMETRY VERIFIED: Row i = Column i".center(70))
        lines.append("-" * 70)
        
        return '\n'.join(lines)


def main():
    if len(sys.argv) < 2:
        print("Usage: python square_poem_generator.py <theme> [size] [model]")
        print()
        print("Examples:")
        print('  python square_poem_generator.py "ocean" 4')
        print('  python square_poem_generator.py "dreams" 5 llama3.2')
        sys.exit(1)
    
    theme = sys.argv[1]
    size = 6
    model = "llama3.2"
    
    for i in range(2, len(sys.argv)):
        arg = sys.argv[i]
        if arg.isdigit():
            size = int(arg)
        else:
            model = arg
    
    if size < 3:
        print("Size must be at least 3", file=sys.stderr)
        sys.exit(1)
    if size > 8:
        print("Warning: big sizes are hard", file=sys.stderr)
    
    solver = SquarePoemCSP(theme, size, model)
    solution = solver.solve()
    
    if solution and solver.verify(solution):
        print(solver.format_output(solution))
        sys.exit(0)
    else:
        print("\nNo solution found", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
