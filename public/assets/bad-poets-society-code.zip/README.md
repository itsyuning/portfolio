# Square Poem Generator

Generates symmetric square poems using backtracking + LLM.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt
python -c "import stanza; stanza.download('en')"

# Start Ollama
ollama serve

# Run
python square_poem_generator.py "ocean" 4
```

## Files

- `square_poem_generator.py` — All core logic
- `prompt_first_row.txt` — LLM prompt for first row
- `prompt_row_completion.txt` — LLM prompt for subsequent rows
- `generated_poems/` — Example outputs
  - `ocean.txt` — Size experiments (7×7 to 12×12 grids)
  - Seven deadly sins poems (5×5 and 6×6)

## For Continued Development

The main file has 4 classes:

1. **`CSPState`** — Holds the grid and tracks used words/lemmas
2. **`ConstraintChecker`** — Validates uniqueness, grammar, perplexity
3. **`DomainGenerator`** — Calls Ollama to generate word candidates
4. **`SquarePoemCSP`** — Main solver with backtracking logic

### To add a new constraint

Add a method in `ConstraintChecker`:
```python
def check_my_constraint(self, words: List[str]) -> Tuple[bool, str]:
    if bad:
        return False, "reason"
    return True, ""
```

Then call it in `_recursive_backtrack()` alongside the other checks.

### To change LLM behavior

- Edit `prompt_first_row.txt` or `prompt_row_completion.txt`
- Adjust `temperature` in `DomainGenerator._call_llm()`
- Pass a different model: `python square_poem_generator.py "theme" 5 mistral`

### Important parameters to tune

In `SquarePoemCSP.__init__()`:
- `max_candidates` — More candidates = better results, slower
- `max_backtracks` — Higher = more attempts before giving up

## Usage

```bash
python square_poem_generator.py <theme> [size] [model]
```

Examples:
```bash
python square_poem_generator.py "ocean" 4
python square_poem_generator.py "dreams" 5 llama3.2
python square_poem_generator.py "autumn"  # defaults to 6x6
```

## Troubleshooting

- **Can't connect to Ollama**: Run `ollama serve` first
- **No solution found**: Try smaller grid or different theme with more specified prompts
- **Slow**: First run loads models (~30s), each LLM call takes 2-10s
